# Analysis on Airbnb Data in Boston and Seattle
Used Boston and Seattle's data to perform comparative analysis, natural language processing and regression model. Provide suggestions to vistors and Airbnb hosts.

## Blog Post
- [Airbnb Data Analysis using Python(Natural Language Analysis, Visualizations, Comparative Analysis and Regression)](https://medium.com/@alanxander0623/airbnb-data-analysis-using-python-natural-language-analysis-visualizations-comparative-analysis-987d2dd29df4) 
